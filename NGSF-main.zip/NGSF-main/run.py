from NGSF.sf_class import Superfit

supernova = Superfit()
supernova.superfit()
